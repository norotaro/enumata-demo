<?php

namespace Norotaro\Enumata\Contracts;

interface Nullable
{
    public static function initialTransitions(): array;
}
